import { useState } from 'react';
import { INITIAL_ORDERS } from './data';
import { Order, AppView, OrderItem, OrderStatus } from './types';
import MainOrderView from './components/MainOrderView';
import DeliveryView from './components/DeliveryView';
import OrderOnlineView, { OnlineOrder, INITIAL_ONLINE_ORDERS } from './components/OrderOnlineView';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, AlertCircle, PlusCircle, BellRing, Sparkles } from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('main');
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [onlineOrders, setOnlineOrders] = useState<OnlineOrder[]>(INITIAL_ONLINE_ORDERS);
  
  // Lifted states to synchronize navigation and notifications click
  const [shopeeActiveTab, setShopeeActiveTab] = useState<OrderStatus>('unconfirmed');
  const [shopeeSelectedOrderId, setShopeeSelectedOrderId] = useState<string | null>(null);
  const [grabActiveTab, setGrabActiveTab] = useState<OrderStatus>('unconfirmed');
  const [grabSelectedOrderId, setGrabSelectedOrderId] = useState<string | null>(null);

  // Stateful notification center
  const [notifications, setNotifications] = useState<any[]>([
    {
      id: 'init-notif-1',
      text: 'Có đơn hàng SPF-901 gửi từ ShopeeFood. Bấm vào để xác nhận đơn hàng của khách hàng',
      orderId: 's-1',
      channel: 'ShopeeFood',
      status: 'unconfirmed',
      timestamp: '10:15 SA',
      read: false
    }
  ]);

  const [nextSimChannel, setNextSimChannel] = useState<'ShopeeFood' | 'Grab'>('ShopeeFood');

  const [toastMessage, setToastMessage] = useState<{
    id: string;
    text: string;
    title?: string;
    channel?: 'Grab' | 'ShopeeFood';
    type: 'success' | 'info' | 'alert';
    pendingCount?: number;
    pendingOrders?: Array<{
      code: string;
      customerName?: string;
      totalPriceStr: string;
      channel?: 'ShopeeFood' | 'Grab';
    }>;
    buttonText?: string;
    onButtonClick?: () => void;
    onClick?: () => void;
  } | null>(null);

  // Derive unconfirmed counts matching the images
  const grabUnconfirmedCount = orders.filter(
    (order) => order.channel === 'Grab' && order.status === 'unconfirmed'
  ).length;

  const shopeeUnconfirmedCount = orders.filter(
    (order) => order.channel === 'ShopeeFood' && order.status === 'unconfirmed'
  ).length;

  const onlineUnconfirmedCount = onlineOrders.filter(
    (order) => order.status === 'unconfirmed'
  ).length;

  // Sound cue or custom animation trigger for simulations
  const playPing = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // A5 note
      gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
      
      oscillator.start();
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
      oscillator.stop(audioCtx.currentTime + 0.3);
    } catch (e) {
      // Audio context block safeguard
    }
  };

  // Toast trigger helper with click action support
  const showToast = (
    text: string, 
    type: 'success' | 'info' | 'alert' = 'success', 
    onClick?: () => void
  ) => {
    const id = Date.now().toString();
    setToastMessage({ id, text, type, onClick });
    setTimeout(() => {
      setToastMessage((prev) => (prev?.id === id ? null : prev));
    }, 8000); // Keep open a bit longer for readability
  };

  // Simulate a realistic new order
  const handleSimulateNewOrder = (requestedChannel?: 'Grab' | 'ShopeeFood') => {
    playPing();

    const channel = requestedChannel || (Math.random() < 0.5 ? 'ShopeeFood' : 'Grab');

    const dishes = [
      { name: 'Cơm tấm sườn bì chả đặc biệt', price: 65000, note: 'Nước mắm nhiều ngọt' },
      { name: 'Phở bò tái lăn Hà Nội', price: 55000, note: 'Ít hành lá, nhiều tương ớt' },
      { name: 'Bún chả Hà Nội đặc sản', price: 60000, note: 'Thêm tỏi băm nhuyễn' },
      { name: 'Nem rán giòn rụm (cái)', price: 15000, note: 'Hạn chế dầu mỡ' },
      { name: 'Bánh mì thịt nướng sả', price: 35000, note: 'Không ăn rau mùi' },
      { name: 'Trà tắc khổng lồ', price: 20000, note: 'Ít đường nhiều đá' },
      { name: 'Lẩu nấm gà ta', price: 380000, note: 'Nấm tươi tổng hợp nhúng lẩu' }
    ];

    // Pick 1 to 3 random dishes
    const numItems = Math.floor(Math.random() * 3) + 1;
    const selectedDishes: OrderItem[] = [];
    let totalPrice = 0;

    for (let i = 0; i < numItems; i++) {
      const dish = dishes[Math.floor(Math.random() * dishes.length)];
      const qty = Math.floor(Math.random() * 2) + 1;
      const id = `${channel.toLowerCase()}-item-${Date.now()}-${i}`;
      const itemTotal = dish.price * qty;
      selectedDishes.push({
        id,
        name: dish.name,
        originalPrice: dish.price,
        qty,
        totalPrice: itemTotal,
        note: Math.random() < 0.35 ? dish.note : undefined
      });
      totalPrice += itemTotal;
    }

    const randomSuffix = Math.floor(100 + Math.random() * 900);
    const code = channel === 'Grab' ? `GF-${randomSuffix}` : `SPF-${randomSuffix}`;

    const VN_FIRST_NAMES = ['Nguyễn', 'Trần', 'Lê', 'Phạm', 'Huỳnh', 'Phan', 'Võ'];
    const VN_MID_NAMES = ['Văn', 'Thị', 'Quốc', 'Thành', 'Minh', 'Đăng', 'Ngọc'];
    const VN_LAST_NAMES = ['Hùng', 'Hải', 'Lan', 'Nam', 'An', 'Bảo', 'Vy', 'Sơn'];

    const randomName = `${VN_FIRST_NAMES[Math.floor(Math.random() * VN_FIRST_NAMES.length)]} ${VN_MID_NAMES[Math.floor(Math.random() * VN_MID_NAMES.length)]} ${VN_LAST_NAMES[Math.floor(Math.random() * VN_LAST_NAMES.length)]}`;
    const randomPhone = `09${Math.floor(10000000 + Math.random() * 90000000)}`;

    const addresses = [
      '12D Điện Biên Phủ, Quận Bình Thạnh',
      '234 Trần Hưng Đạo, Quận 1',
      '45 Nguyễn Văn Cừ, Quận 5',
      '89 Lê Văn Sỹ, Quận Phú Nhuận',
      '105 Võ Văn Tần, Quận 3',
      '55 Song Hành, Quận 2'
    ];
    const randomAddress = `${addresses[Math.floor(Math.random() * addresses.length)]}, TP. Hồ Chí Minh`;

    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const month = (now.getMonth() + 1).toString().padStart(2, '0');
    const day = now.getDate().toString().padStart(2, '0');
    const year = now.getFullYear();

    const orderTime = `${hours}:${minutes} - ${month}/${day}/${year}`;

    const recDate = new Date(now.getTime() + 45 * 60000);
    const recHours = recDate.getHours().toString().padStart(2, '0');
    const recMinutes = recDate.getMinutes().toString().padStart(2, '0');
    const recMonth = (recDate.getMonth() + 1).toString().padStart(2, '0');
    const recDay = recDate.getDate().toString().padStart(2, '0');
    const recYear = recDate.getFullYear();
    const receiveTime = `${recHours}:${recMinutes} - ${recMonth}/${recDay}/${recYear}`;

    const newOrder: Order = {
      id: `sim-${Date.now()}`,
      code,
      channel,
      itemsCount: selectedDishes.length,
      totalPrice,
      orderTime,
      status: 'unconfirmed',
      customerPhone: randomPhone,
      deliveryAddress: randomAddress,
      driverName: `${randomName} (${channel})`,
      driverPhone: `09${Math.floor(10000000 + Math.random() * 90000000)}`,
      items: selectedDishes,
      note: channel === 'ShopeeFood' ? 'Giao đơn hàng nhanh, đóng gói cẩn thận.' : undefined,
      subtotalDiscounted: Math.round(totalPrice * 0.95),
      billDiscount: Math.round(totalPrice * 0.05),
      deliveryFee: 15000,
      platformFee: 4000,
      driverTip: 2000
    };

    setOrders((prev) => [newOrder, ...prev]);

    // Also add to onlineOrders so it appears in the "Order Online" tab under "Chưa xác nhận"
    const newOnlineOrder: OnlineOrder = {
      id: `oo-${Date.now()}`,
      code,
      customerName: randomName,
      phone: randomPhone,
      address: randomAddress,
      orderTime,
      receiveTime,
      timeAgo: 'Vừa xong',
      itemsCountStr: `${selectedDishes.length} Món`,
      totalPriceStr: `${totalPrice.toLocaleString('vi-VN')} đ`,
      totalPriceNum: totalPrice,
      paymentMethod: 'Thanh toán qua ví điện tử',
      channel,
      status: 'unconfirmed',
      items: selectedDishes.map((d, index) => ({
        id: `ooi-${Date.now()}-${index}`,
        name: d.name,
        qtyStr: `${d.qty}`,
        totalPriceStr: `${d.totalPrice.toLocaleString('vi-VN')} đ`,
        note: d.note
      }))
    };
    setOnlineOrders((prev) => [newOnlineOrder, ...prev]);

    // Add to stateful notifications
    const newNotif = {
      id: `notif-${Date.now()}`,
      text: `Có đơn hàng ${code} gửi từ ${channel}. Bấm vào để xác nhận đơn hàng`,
      orderId: newOrder.id,
      channel,
      status: 'unconfirmed',
      timestamp: `${hours}:${minutes}`,
      read: false
    };
    setNotifications((prev) => [newNotif, ...prev]);

    // Trigger push notification on the right corner
    const unconfirmedList = [newOnlineOrder, ...onlineOrders.filter((o) => o.status === 'unconfirmed')];
    const currentUnconfirmedCount = unconfirmedList.length;

    setToastMessage({
      id: Date.now().toString(),
      title: `Đơn hàng mới từ ${channel}`,
      text: `Mã đơn: ${code} - Giá: ${totalPrice.toLocaleString('vi-VN')}đ`,
      type: 'info',
      channel,
      pendingCount: currentUnconfirmedCount,
      pendingOrders: unconfirmedList.map((o) => ({
        code: o.code,
        customerName: o.customerName,
        totalPriceStr: o.totalPriceStr,
        channel: o.channel || (o.code.startsWith('GF') ? 'Grab' : 'ShopeeFood')
      })),
      buttonText: 'Xem danh sách đơn',
      onButtonClick: () => {
        setCurrentView('orderonline');
        setToastMessage(null);
      }
    });
  };

  // Notification click handler
  const handleNotificationClick = (notif: any) => {
    setCurrentView(notif.channel.toLowerCase() as AppView);
    if (notif.channel === 'ShopeeFood') {
      setShopeeActiveTab(notif.status);
      setShopeeSelectedOrderId(notif.orderId);
    } else {
      setGrabActiveTab(notif.status);
      setGrabSelectedOrderId(notif.orderId);
    }
    // Mark as read
    setNotifications((prev) =>
      prev.map((n) => (n.id === notif.id ? { ...n, read: true } : n))
    );
  };

  // Confirm order action (unconfirmed -> confirmed)
  const handleConfirmOrder = (orderId: string) => {
    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === orderId) {
          // If a notification exists for this order, mark it as read and update its state status to confirmed
          setNotifications((prevNotif) =>
            prevNotif.map((n) => n.orderId === orderId ? { ...n, read: true, status: 'confirmed' } : n)
          );
          return { ...order, status: 'confirmed' };
        }
        return order;
      })
    );
  };

  // Complete order action (confirmed -> completed)
  const handleCompleteOrder = (orderId: string) => {
    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === orderId) {
          showToast(`🌟 Đơn hàng ${order.code} đã hoàn thành và giao đi!`, 'success');
          // Update notification status
          setNotifications((prevNotif) =>
            prevNotif.map((n) => n.orderId === orderId ? { ...n, read: true, status: 'completed' } : n)
          );
          return { ...order, status: 'completed' };
        }
        return order;
      })
    );
  };

  // Delete/Reject option (updates to 'cancelled' so they show in Completed tab as specified by brief)
  const handleDeleteOrder = (orderId: string, reason?: string) => {
    const orderToDel = orders.find((o) => o.id === orderId);
    if (!orderToDel) return;
    
    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === orderId) {
          return { ...order, status: 'cancelled' };
        }
        return order;
      })
    );
    // Update notification status
    setNotifications((prevNotif) =>
      prevNotif.map((n) => n.orderId === orderId ? { ...n, read: true, status: 'cancelled' } : n)
    );
    showToast(`❌ Đã từ chối đơn hàng ${orderToDel.code}${reason ? `: ${reason}` : ''}!`, 'alert');
  };

  return (
    <div id="app-viewport-wrapper" className="h-screen w-screen bg-[#10141d] flex items-center justify-center overflow-hidden font-sans">
      
      {/* Push Notification Overlay on the right corner */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            id="toast-notification-banner"
            initial={{ opacity: 0, x: 80, scale: 0.9 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 80, scale: 0.9 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="fixed top-14 right-4 z-50 w-80 sm:w-96 bg-white text-gray-900 rounded-2xl shadow-2xl p-4 flex flex-col gap-3"
          >
            <div className="flex items-center justify-between border-b border-gray-100 pb-2.5">
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-[16px] text-gray-900 tracking-tight">
                  Order Online
                </span>
                {toastMessage.pendingCount && toastMessage.pendingCount >= 1 && (
                  <span className="bg-orange-100 text-orange-800 text-[13px] font-bold px-2 py-0.5 rounded-md">
                    {toastMessage.pendingCount} đơn chờ xác nhận
                  </span>
                )}
              </div>
              <button 
                id="close-toast-btn"
                onClick={() => setToastMessage(null)} 
                className="text-gray-400 hover:text-gray-700 transition text-sm font-bold p-1 rounded-full hover:bg-gray-100"
              >
                ✕
              </button>
            </div>

            {toastMessage.pendingOrders && toastMessage.pendingOrders.length > 0 ? (
              <div className="relative rounded-xl overflow-hidden">
                <div className="flex flex-col gap-2 bg-gray-50 p-2.5 rounded-xl max-h-[200px] overflow-y-auto" id="toast-text-content">
                  {toastMessage.pendingOrders.map((ord, idx) => {
                    const isGrab = ord.channel === 'Grab' || ord.code.startsWith('GF');
                    return (
                      <div key={idx} className="flex items-center justify-between text-[13px] py-2.5 px-3 bg-white rounded-xl border border-gray-100 shadow-2xs">
                        <div className="flex items-center gap-2.5 min-w-0 pr-2">
                          <img 
                            src={isGrab 
                              ? "https://amismisa.misacdn.net/chat/api/file/v1/file/image/5001/misa.jpg?fileID=71956450-e39c-4bc5-98e9-aea9568acff0.png&preview=true&cId=69de03a24a7bbf58f889e11d&tCode=misa&tenantcode=misa"
                              : "https://amismisa.misacdn.net/chat/api/file/v1/file/image/5001/misa.jpg?fileID=86c3811c-13d4-46c7-8dc2-f484b09d7552.png&preview=true&cId=69de03a24a7bbf58f889e11d&tCode=misa&tenantcode=misa"
                            }
                            alt={isGrab ? "Grab" : "ShopeeFood"}
                            className="w-[24px] h-[24px] object-contain shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <span className="font-bold text-gray-900 text-[13px]">{ord.code}</span>
                        </div>
                        <span className="font-extrabold shrink-0 text-[13px] text-gray-900">
                          {ord.totalPriceStr}
                        </span>
                      </div>
                    );
                  })}
                </div>
                {toastMessage.pendingOrders.length > 4 && (
                  <div className="absolute bottom-0 left-0 right-0 h-10 bg-gradient-to-t from-gray-100/90 via-gray-50/70 to-transparent pointer-events-none rounded-b-xl" />
                )}
              </div>
            ) : (
              <div className="text-[13px] text-gray-700 leading-relaxed font-semibold bg-gray-50 p-3 rounded-xl flex items-center gap-2.5" id="toast-text-content">
                {toastMessage.channel && (
                  <img 
                    src={toastMessage.channel === 'Grab'
                      ? "https://amismisa.misacdn.net/chat/api/file/v1/file/image/5001/misa.jpg?fileID=71956450-e39c-4bc5-98e9-aea9568acff0.png&preview=true&cId=69de03a24a7bbf58f889e11d&tCode=misa&tenantcode=misa"
                      : "https://amismisa.misacdn.net/chat/api/file/v1/file/image/5001/misa.jpg?fileID=86c3811c-13d4-46c7-8dc2-f484b09d7552.png&preview=true&cId=69de03a24a7bbf58f889e11d&tCode=misa&tenantcode=misa"
                    }
                    alt={toastMessage.channel}
                    className="w-[24px] h-[24px] object-contain shrink-0"
                    referrerPolicy="no-referrer"
                  />
                )}
                <span className="text-[13px]">{toastMessage.text}</span>
              </div>
            )}

            {toastMessage.buttonText && toastMessage.onButtonClick ? (
              <button 
                id="btn-action-push-receive"
                onClick={toastMessage.onButtonClick}
                className="w-full bg-[#0973B9] hover:bg-[#075d97] text-white font-bold text-xs h-[32px] rounded-lg shadow-sm flex items-center justify-center transition cursor-pointer"
              >
                <span>{toastMessage.buttonText}</span>
              </button>
            ) : toastMessage.onClick && (
              <button 
                onClick={toastMessage.onClick}
                className="w-full bg-[#0973B9] hover:bg-[#075d97] text-white font-bold text-xs h-[32px] rounded-lg shadow transition flex items-center justify-center cursor-pointer"
              >
                Xem danh sách đơn
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Container mirroring POS tablet system */}
      <main id="pos-screen" className="w-full h-full bg-white flex flex-col overflow-hidden shadow-2xl relative">
        {currentView === 'main' ? (
          <div key="main-view" className="w-full h-full flex flex-col">
            <MainOrderView
              grabUnconfirmedCount={grabUnconfirmedCount}
              shopeeUnconfirmedCount={shopeeUnconfirmedCount}
              onlineUnconfirmedCount={onlineUnconfirmedCount}
              onNavigateToView={(view) => setCurrentView(view)}
              onSimulateNewOrder={handleSimulateNewOrder}
              notifications={notifications}
              onNotificationClick={handleNotificationClick}
            />
          </div>
        ) : currentView === 'orderonline' ? (
          <div key="orderonline-view" className="w-full h-full flex flex-col">
            <OrderOnlineView
              onBackToMain={() => setCurrentView('main')}
              onNavigateToView={(view) => setCurrentView(view)}
              notifications={notifications}
              onNotificationClick={handleNotificationClick}
              orders={onlineOrders}
              setOrders={setOnlineOrders}
            />
          </div>
        ) : (
          <div key={`${currentView}-view`} className="w-full h-full flex flex-col">
            <DeliveryView
              channel={currentView === 'grab' ? 'Grab' : 'ShopeeFood'}
              orders={orders}
              onBackToMain={() => setCurrentView('main')}
              onConfirmOrder={handleConfirmOrder}
              onCompleteOrder={handleCompleteOrder}
              onDeleteOrder={handleDeleteOrder}
              
              activeTab={currentView === 'grab' ? grabActiveTab : shopeeActiveTab}
              setActiveTab={currentView === 'grab' ? setGrabActiveTab : setShopeeActiveTab}
              selectedOrderId={currentView === 'grab' ? grabSelectedOrderId : shopeeSelectedOrderId}
              setSelectedOrderId={currentView === 'grab' ? setGrabSelectedOrderId : setShopeeSelectedOrderId}
              notifications={notifications}
              onNotificationClick={handleNotificationClick}
            />
          </div>
        )}
      </main>
    </div>
  );
}
