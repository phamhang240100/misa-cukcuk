import React from 'react';
import { 
  Home, 
  Plus, 
  Globe, 
  Cloud, 
  RefreshCw, 
  Bell, 
  BellRing,
  Clock, 
  User, 
  ChevronDown, 
  ChevronUp, 
  Search, 
  Menu,
  MessageSquare,
  Sparkles
} from 'lucide-react';
import { Order, AppView } from '../types';

interface MainOrderViewProps {
  grabUnconfirmedCount: number;
  shopeeUnconfirmedCount: number;
  onlineUnconfirmedCount: number;
  onNavigateToView: (view: AppView) => void;
  onSimulateNewOrder: (channel?: 'Grab' | 'ShopeeFood') => void;
  notifications: any[];
  onNotificationClick: (notif: any) => void;
}

export default function MainOrderView({
  grabUnconfirmedCount,
  shopeeUnconfirmedCount,
  onlineUnconfirmedCount,
  onNavigateToView,
  onSimulateNewOrder,
  notifications,
  onNotificationClick
}: MainOrderViewProps) {
  const [dropdownOpen, setDropdownOpen] = React.useState(false);
  const [activeSubTab, setActiveSubTab] = React.useState<string>('payment');
  const [showNotificationsDropdown, setShowNotificationsDropdown] = React.useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div id="main-order-view-container" className="flex flex-col h-full bg-white select-none text-[13px] font-sans">
      {/* Blue Top Header Bar */}
      <header id="main-header" className="bg-[#0973B9] h-11 text-white flex items-center justify-between px-2 shrink-0 border-b border-[#00497D] font-medium">
        <div id="header-left" className="flex items-center h-full">
          {/* Home Icon */}
          <button id="home-nav-btn" className="hover:bg-[#00497D] h-full px-3 flex items-center transition">
            <Home className="w-5 h-5" />
          </button>
          
          {/* Active Tab: Order */}
          <div id="active-order-tab" className="bg-white text-[#0973B9] h-full flex items-center px-4 font-bold text-sm gap-1.5 shadow-sm rounded-t-lg">
            <Globe className="w-4 h-4 text-[#0973B9]" />
            <span id="label-order" className="font-extrabold text-[#0973B9]">Order</span>
          </div>

          {/* Tab: Sơ đồ */}
          <button id="sodo-nav-btn" className="hover:bg-[#00497D] h-full px-4 flex items-center text-white/90 text-sm transition">
            <span id="label-sodo">Sơ đồ</span>
          </button>

          {/* Tab: Order Online */}
          <button 
            id="order-online-nav-btn" 
            onClick={() => onNavigateToView('orderonline')} 
            className="hover:bg-[#00497D] h-full px-4 flex items-center text-white/90 text-sm transition gap-1.5 relative"
          >
            <div className="relative flex items-center justify-center">
              {onlineUnconfirmedCount > 0 ? (
                <Bell className="w-5 h-5 text-amber-300 animate-bell-flash transition-transform duration-300" />
              ) : (
                <Bell className="w-4 h-4 text-white/80" />
              )}
              {onlineUnconfirmedCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500 border border-white"></span>
                </span>
              )}
            </div>
            <span id="label-order-online" className={onlineUnconfirmedCount > 0 ? 'font-bold text-amber-200' : ''}>
              Order Online
            </span>
            {onlineUnconfirmedCount > 0 && (
              <span className="bg-red-600 text-white text-[11px] font-extrabold px-1.5 py-0.5 rounded-full leading-none ml-0.5 animate-pulse shadow-sm">
                {onlineUnconfirmedCount}
              </span>
            )}
          </button>
        </div>

        {/* Header Center and Actions */}
        <div id="header-right" className="flex items-center h-full gap-1">
          {/* Green plus order button */}
          <button id="add-order-btn" className="flex items-center gap-1 bg-transparent hover:bg-white/10 px-3 py-1.5 rounded text-white font-bold text-xs transition mr-2 uppercase border border-white/30">
            <Plus className="w-4 h-4" />
            <span>Order</span>
          </button>

          {/* Dropdown switch list button */}
          <button 
            id="menu-toggle-btn"
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className={`h-full px-3 flex items-center hover:bg-[#00497D] transition relative ${dropdownOpen ? 'bg-[#00497D]' : ''}`}
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Vertical divider */}
          <div id="divider-right" className="h-5 w-px bg-white/20 mx-1"></div>

          {/* Web notification glove icon */}
          <button id="globe-btn" className="hover:bg-[#00497D] p-2 rounded relative transition">
            <Globe className="w-4 h-4" />
            <span id="badge-globe" className="absolute top-1 right-1 bg-red-600 text-[9px] font-bold text-white leading-none rounded-full min-w-4 h-4 flex items-center justify-center p-0.5">9</span>
          </button>

          {/* Cloud Upload Icon */}
          <button id="cloud-sync-btn" className="hover:bg-[#00497D] p-2 rounded transition">
            <Cloud className="w-4 h-4" />
          </button>

          {/* Refresh/Exchange icon */}
          <button id="exchange-sync-btn" className="hover:bg-[#00497D] p-2 rounded transition">
            <RefreshCw className="w-4 h-4" />
          </button>

          {/* Alert / Bell Notification icon with custom dropdown */}
          <div className="relative">
            <button 
              id="bell-alert-btn" 
              onClick={() => setShowNotificationsDropdown(!showNotificationsDropdown)}
              className="hover:bg-[#00497D] p-2 rounded relative transition"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span id="badge-bell" className="absolute top-1 right-1 bg-red-600 text-[9px] font-bold text-white leading-none rounded-full w-4 h-4 flex items-center justify-center p-0.5 animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>

            {showNotificationsDropdown && (
              <div className="absolute right-0 top-11 z-50 w-[360px] bg-white text-gray-900 rounded-lg shadow-2xl border border-gray-200 overflow-hidden animate-in fade-in slide-in-from-top-1 duration-150">
                <div className="p-3 bg-[#0973B9] text-white font-bold flex items-center justify-between">
                  <span>Thông báo đơn hàng ({unreadCount})</span>
                  <button onClick={() => setShowNotificationsDropdown(false)} className="text-white hover:text-gray-200">✕</button>
                </div>
                <div className="max-h-[300px] overflow-y-auto">
                  {notifications.length === 0 ? (
                    <div className="p-4 text-center text-gray-500 font-medium">Không có thông báo mới.</div>
                  ) : (
                    notifications.map((notif) => (
                      <div 
                        key={notif.id}
                        onClick={() => {
                          onNotificationClick(notif);
                          setShowNotificationsDropdown(false);
                        }}
                        className={`p-3 border-b border-gray-100 hover:bg-[#F0F6FE] cursor-pointer transition-colors flex gap-2.5 items-start ${
                          notif.read ? 'bg-white opacity-75' : 'bg-[#F0F6FE]'
                        }`}
                      >
                        <div className="w-2 h-2 rounded-full bg-[#0973B9] mt-1.5 shrink-0" style={{ visibility: notif.read ? 'hidden' : 'visible' }} />
                        <div className="flex-1 flex flex-col gap-0.5">
                          <span className="text-xs font-semibold leading-normal text-gray-900">{notif.text}</span>
                          <span className="text-[10px] text-gray-400 font-mono font-bold">{notif.timestamp}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Clock icon */}
          <button id="clock-btn" className="hover:bg-[#00497D] p-2 rounded transition">
            <Clock className="w-4 h-4" />
          </button>

          {/* User Profile */}
          <button id="user-profile-btn" className="hover:bg-[#00497D] p-2 rounded transition flex items-center justify-center">
            <User className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Sub-Header bar / Filters selection */}
      <div id="filters-navbar" className="bg-white border-b border-gray-200 h-10 px-2 flex items-center justify-between shrink-0">
        <div id="sub-tabs-left" className="flex items-center gap-1.5 h-full py-1">
          <button
            id="tab-unpaid"
            onClick={() => setActiveSubTab('payment')}
            className={`h-full px-4 flex items-center justify-center rounded font-semibold text-center border transition ${
              activeSubTab === 'payment'
                ? 'bg-[#00497D] text-white border-[#00497D]'
                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
            }`}
          >
            Chờ thanh toán (0)
          </button>

          <button
            id="tab-takeaway"
            onClick={() => setActiveSubTab('takeaway')}
            className={`h-full px-4 flex items-center justify-center rounded font-semibold text-center border transition ${
              activeSubTab === 'takeaway'
                ? 'bg-[#00497D] text-white border-[#00497D]'
                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
            }`}
          >
            Mang về (0)
          </button>

          <button
            id="tab-delivery"
            onClick={() => setActiveSubTab('delivery')}
            className={`h-full px-4 flex items-center justify-center rounded font-semibold text-center border transition ${
              activeSubTab === 'delivery'
                ? 'bg-[#00497D] text-white border-[#00497D]'
                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
            }`}
          >
            Chờ giao hàng (0)
          </button>

          <button
            id="tab-reservation"
            onClick={() => setActiveSubTab('reservation')}
            className={`h-full px-4 flex items-center justify-center rounded font-semibold text-center border transition ${
              activeSubTab === 'reservation'
                ? 'bg-[#00497D] text-white border-[#00497D]'
                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
            }`}
          >
            Đặt trước (0)
          </button>
        </div>

        <div id="sub-filters-right" className="flex items-center gap-2">
          {/* Find Table select box */}
          <div id="find-table-search" className="relative flex items-center bg-white border border-[#ccc] rounded px-2 py-1 h-7 text-xs w-28">
            <span id="find-table-text" className="text-gray-500 mr-auto truncate">Tìm bàn</span>
            <ChevronDown className="w-3.5 h-3.5 text-gray-500" />
          </div>

          {/* Search bar */}
          <div id="search-bar-input-container" className="relative flex items-center bg-white border border-[#ccc] rounded px-2 py-1 h-7 w-44">
            <input 
              id="search-input"
              type="text" 
              placeholder="Tìm theo..." 
              className="outline-none text-[11px] w-full text-gray-700 pr-4"
              disabled
            />
            <Search className="w-3.5 h-3.5 text-gray-400 absolute right-1.5" />
          </div>
        </div>
      </div>

      {/* Main Workspace Body with Dropdown Sidebar Layout */}
      <div id="mainscreen-body" className="flex-1 relative flex overflow-hidden">
        
        {/* Left Side: Main Empty placeholder exactly as in Image 1 */}
        <div id="empty-workspace" className="flex-1 flex flex-col items-center justify-center p-6 text-center text-gray-500 relative">
          <div id="logo-fork-spoon-circle" className="w-40 h-40 rounded-full border-8 border-gray-300/60 flex items-center justify-center mb-6 text-gray-300/80">
            {/* Custom SVG inside the circle representing Spoon & Fork */}
            <svg id="fork-spoon-svg" className="w-20 h-20 fill-current opacity-70" viewBox="0 0 24 24">
              <path d="M11 9H9V2H7v7H5V2H3v7c0 2.12 1.66 3.84 3.75 3.97V22h2.5v-9.03C11.34 12.84 13 11.12 13 9V2h-2v7zm10-7h-3c-1.1 0-2 .9-2 2v5c0 1.66 1.34 3 3 3v10h2V12c1.66 0 3-1.34 3-3V4c0-2-2-2-2-2z" />
            </svg>
          </div>
          <p id="cooking-placeholder-text" className="text-base text-gray-500/90 font-medium">
            Nhà hàng chưa có order nào, vui lòng <strong className="text-gray-700">Thêm order</strong> để ghi món cho khách
          </p>
          <button 
            id="action-prompt-tip" 
            className="mt-3 text-xs bg-white hover:bg-gray-50 text-gray-700 font-medium px-3.5 py-1.5 rounded-lg border border-gray-300 shadow-sm transition flex items-center gap-1.5 cursor-pointer" 
            onClick={() => onSimulateNewOrder()}
          >
            <span>💡 Click vào đây để nhận đơn</span>
          </button>
        </div>

        {/* Right Side: Popover Dropdown (Matches dropdown menu from Image 1) */}
        {dropdownOpen && (
          <div 
            id="delivery-popover-dropdown" 
            className="absolute right-2 top-2 z-20 w-72 bg-white rounded-md shadow-2xl border border-gray-200 text-gray-800 flex flex-col shrink-0 overflow-hidden text-[13px]"
          >
            <div id="dropdown-header" className="bg-gray-50 border-b border-gray-100 px-3 py-2 text-[11px] uppercase tracking-wider font-bold text-gray-400 flex items-center justify-between">
              <span>Phương thức trực tuyến</span>
              <button onClick={() => setDropdownOpen(false)} className="text-gray-400 hover:text-gray-600 font-normal normal-case">Đóng ✕</button>
            </div>
            
            <div id="dropdown-list" className="py-1">
              
              {/* Option 1: Đặt giao hàng từ 5Food */}
              <button 
                id="opt-5food-order"
                className="w-full text-left px-4 py-2.5 hover:bg-gray-100 flex items-center transition"
              >
                <div id="icon-5f-order" className="w-5 h-5 mr-3 flex items-center justify-center text-blue-600 font-black text-xs border border-blue-600 rounded">
                  5F
                </div>
                <span id="txt-5f-order">Đặt giao hàng từ 5Food</span>
              </button>

              {/* Option 2: Đặt giao hàng trên Web */}
              <button 
                id="opt-web-order"
                className="w-full text-left px-4 py-2.5 hover:bg-gray-100 flex items-center transition"
              >
                <Globe id="icon-web-order" className="w-4 h-4 mr-3 text-cyan-600" />
                <span id="txt-web-order">Đặt giao hàng trên Web</span>
              </button>

              {/* Option 3: Giao hàng từ Grab (HIGHLIGHTED & INTERACTIVE) */}
              <button 
                id="opt-grab-order"
                onClick={() => onNavigateToView('grab')}
                className="w-full text-left px-4 py-3 bg-green-500/5 hover:bg-green-500/10 flex items-center justify-between transition border-y border-green-500/12 group relative"
              >
                <div id="grab-opt-left" className="flex items-center">
                  <img 
                    id="icon-grab-food" 
                    src="https://misajsc.amis.vn/oneai/g1/api/file/v1/files/image?fileType=5003&fileId=5e1a7fa2-2197-4aa7-8b10-1f2fe9dbf40d.png&isTemp=true&tenantCode=misa" 
                    className="w-5 h-5 mr-3 rounded-full object-cover shadow-sm" 
                    referrerPolicy="no-referrer" 
                    alt="Grab" 
                  />
                  <span id="txt-grab-food" className="font-semibold text-green-800 group-hover:text-green-900">
                    Giao hàng từ Grab
                  </span>
                </div>
                <span id="badge-grab-count" className="bg-red-500 text-white font-bold text-xs h-5 px-2 rounded-full flex items-center justify-center">
                  {grabUnconfirmedCount}
                </span>
              </button>

              {/* Option 4: Giao hàng từ ShopeeFood (THE NEWLY REQUESTED COMPONENT ACTIVE) */}
              <button 
                id="opt-shopee-food-order"
                onClick={() => onNavigateToView('shopeefood')}
                className="w-full text-left px-4 py-3 bg-orange-500/5 hover:bg-orange-500/10 flex items-center justify-between transition border-b border-orange-500/12 group relative"
              >
                <div id="shopee-opt-left" className="flex items-center">
                  <img 
                    id="icon-shopee-food" 
                    src="https://misajsc.amis.vn/oneai/g1/api/file/v1/files/image?fileType=5003&fileId=14b33c29-a6cd-4dc4-984c-e5c629967f3f.png&isTemp=true&tenantCode=misa" 
                    className="w-5 h-5 mr-3 rounded-full object-cover shadow-sm" 
                    referrerPolicy="no-referrer" 
                    alt="ShopeeFood" 
                  />
                  <span id="txt-shopee-food" className="font-semibold text-orange-850 group-hover:text-orange-900">
                    Giao hàng từ ShopeeFood
                  </span>
                </div>
                {/* Number count no longer blinks */}
                <span id="badge-shopee-count" className="bg-orange-600 text-white font-bold text-xs h-5 px-2 rounded-full flex items-center justify-center">
                  {shopeeUnconfirmedCount}
                </span>

                {/* Sparkling indicator for the newly requested addition */}
                <div className="absolute -top-1 -right-1 bg-amber-500 text-white text-[8px] font-extrabold px-1 rounded-sm rotate-12 scale-90" id="shopee-new-badge">NEW</div>
              </button>

              {/* Option 5: Mời khách hàng sử dụng 5Food */}
              <button 
                id="opt-invite"
                className="w-full text-left px-4 py-2.5 hover:bg-gray-100 flex items-center text-gray-600 transition"
              >
                <MessageSquare id="icon-invite" className="w-4 h-4 mr-3 text-blue-500" />
                <span id="txt-invite">Mời khách hàng sử dụng 5Food</span>
              </button>

              {/* Option 6: Đặt chỗ từ 5Food (0) */}
              <button 
                id="opt-res-5f"
                className="w-full text-left px-4 py-2.5 hover:bg-gray-100 flex items-center justify-between text-gray-500 transition"
              >
                <div id="res-5f-left" className="flex items-center">
                  <span id="icon-res-5f" className="w-4 h-4 mr-3 border border-gray-300 rounded flex items-center justify-center text-[10px]">🗓</span>
                  <span id="txt-res-5f">Đặt chỗ từ 5Food</span>
                </div>
                <span id="badge-res-5f" className="text-gray-400 text-xs">(0)</span>
              </button>

              {/* Option 7: Khách hàng chưa đồng bộ (0) */}
              <button 
                id="opt-sync-customers"
                className="w-full text-left px-4 py-2.5 hover:bg-gray-100 flex items-center justify-between text-gray-500 transition"
              >
                <div id="sync-customers-left" className="flex items-center">
                  <User id="icon-sync-customers" className="w-4 h-4 mr-3 text-gray-400" />
                  <span id="txt-sync-customers">Khách hàng chưa đồng bộ</span>
                </div>
                <span id="badge-sync-customers" className="text-gray-400 text-xs">(0)</span>
              </button>

              {/* Option 8: Hóa đơn chưa đồng bộ (0) */}
              <button 
                id="opt-sync-invoices"
                className="w-full text-left px-4 py-2.5 hover:bg-gray-100 flex items-center justify-between text-gray-500 transition"
              >
                <div id="sync-invoices-left" className="flex items-center">
                  <span id="icon-sync-invoices" className="w-4 h-4 mr-3 border border-gray-300 rounded flex items-center justify-center text-[10px]">🧾</span>
                  <span id="txt-sync-invoices">Hóa đơn chưa đồng bộ</span>
                </div>
                <span id="badge-sync-invoices" className="text-gray-400 text-xs">(0)</span>
              </button>

            </div>
          </div>
        )}
      </div>

      {/* Primary Action bar above diagnostic footer */}
      <div id="main-action-toolbar" className="bg-white border-t border-gray-200 h-8 px-2 flex items-center justify-between shrink-0 text-xs text-gray-800">
        <div id="toolbar-left" className="flex items-center gap-1">
          {/* Dropdown - Tất cả - */}
          <div id="dropdown-all-orders" className="bg-white border border-[#ccc] px-2 py-0.5 h-6 rounded flex items-center gap-2 cursor-pointer w-24">
            <span id="dropdown-all-text" className="text-gray-700 truncate">- Tất cả -</span>
            <ChevronDown className="w-3 h-3 text-gray-500" />
          </div>

          <div id="order-count-indicator" className="h-full px-2 flex items-center font-semibold text-gray-700">
            Tổng số Order: <span className="ml-1 text-black font-extrabold">0</span>
          </div>
        </div>

        <div id="toolbar-mid" className="font-bold text-gray-700 select-all">
          Thêm Order: F2 hoặc ALT+T
        </div>

        <div id="toolbar-right" className="flex items-center gap-1">
          {/* chevron navigation button mimics */}
          <button id="chev-up-nav-btn" className="bg-white border border-[#ccc] hover:bg-gray-50 p-1 rounded h-6 w-8 flex items-center justify-center transition">
            <ChevronUp className="w-3.5 h-3.5 text-gray-600" />
          </button>
          <button id="chev-down-nav-btn" className="bg-white border border-[#ccc] hover:bg-gray-50 p-1 rounded h-6 w-8 flex items-center justify-center transition">
            <ChevronDown className="w-3.5 h-3.5 text-gray-600" />
          </button>
        </div>
      </div>

      {/* CUKCUK MISA Diagnostic Footer */}
      <footer id="cukcuk-footer" className="bg-[#0973B9] h-6 text-[#ebd5ff] font-sans text-[11px] flex items-center justify-between px-3 shrink-0 select-text">
        <div id="footer-db" className="font-semibold text-white/90">
          dblongviet - dblongviet.cukcuk2.misa.local
        </div>

        <div id="footer-support" className="flex items-center gap-2 font-medium">
          <span>Tổng đài tư vấn: <strong className="text-white">MISA SUPPORT</strong></span>
          <span className="text-white/45">|</span>
          <span>OVR</span>
          <span className="text-white/45">|</span>
          <span>NUM</span>
        </div>

        <div id="footer-time" className="flex items-center gap-2 font-mono">
          <span>SCRL</span>
          <span className="text-white/45">|</span>
          <span className="text-yellow-300 font-bold">04:06 CH - 17/03/2021</span>
        </div>
      </footer>
    </div>
  );
}
